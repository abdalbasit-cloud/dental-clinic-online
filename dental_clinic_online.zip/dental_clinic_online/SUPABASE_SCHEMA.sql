-- The application uses SQLAlchemy to create/update its tables automatically.
-- This file is provided as a reference/verification schema for Supabase PostgreSQL.
-- Run the application once after setting DATABASE_URL; it will create the tables.
-- Do NOT store Supabase service-role keys in this file or in GitHub.

-- Tables created by the application:
-- users, dentist, treatment_type, patient, visit
