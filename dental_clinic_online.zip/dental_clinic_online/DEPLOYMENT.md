# نشر نظام عيادة الأسنان Online

## البنية المجانية المقترحة
- Render Free Web Service لتشغيل Flask/Gunicorn.
- Supabase PostgreSQL لحفظ بيانات المرضى بشكل مركزي.

Render يدعم نشر Flask مباشرة باستخدام Python وGunicorn، والخطة Free متاحة للاختبار والمشاريع الصغيرة، لكنها توقف الخدمة بعد 15 دقيقة من عدم النشاط؛ لذلك قد يستغرق أول فتح بعد الخمول نحو دقيقة.

## 1) قاعدة Supabase
في مشروع Supabase:
1. افتح Connect / Database.
2. انسخ PostgreSQL connection string أو pooler connection string.
3. احتفظ به سريًا.
4. لا تضعه داخل GitHub.

التطبيق ينشئ الجداول تلقائيًا عند تشغيله:
- users
- dentist
- treatment_type
- patient
- visit

## 2) GitHub
ارفع محتويات مجلد `dental_clinic_online` إلى مستودع GitHub خاص.

لا ترفع `.env` أو أي مفاتيح سرية.

## 3) Render
1. Render Dashboard > New > Web Service.
2. اربط مستودع GitHub.
3. اختر Python.
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `gunicorn app:app`
6. اختر Free.
7. أضف Environment Variables:
   - `DATABASE_URL` = رابط PostgreSQL من Supabase
   - `SECRET_KEY` = قيمة عشوائية طويلة
   - `ADMIN_PASSWORD` = كلمة مرور قوية
   - `SESSION_COOKIE_SECURE` = `1`
8. Deploy.

## 4) فحص التشغيل
بعد النشر افتح `/health`. يجب أن يظهر:
`{"status":"ok"}`

## 5) الدخول الأول
اسم المستخدم الافتراضي: `admin`
كلمة المرور: القيمة التي وضعتها في `ADMIN_PASSWORD`.

غيّر كلمة المرور الافتراضية قبل إدخال بيانات مرضى حقيقية.

## تنبيه مهم
بيانات المرضى بيانات حساسة. استخدم HTTPS، كلمة مرور قوية، صلاحيات وصول محدودة، ونسخًا احتياطية دورية لقاعدة PostgreSQL. لا تستخدم SQLite على استضافة ذات نظام ملفات مؤقت.
