import os
from datetime import date, datetime
from decimal import Decimal
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change-this-secret-key')
db_url = os.environ.get('DATABASE_URL', 'sqlite:///dental_clinic.db')
if db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://', 1)
app.config['SQLALCHEMY_DATABASE_URI'] = db_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', '1') == '1'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), default='admin')

class Dentist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, unique=True)
    active = db.Column(db.Boolean, default=True)

class TreatmentType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, unique=True)
    active = db.Column(db.Boolean, default=True)

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_no = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    phone = db.Column(db.String(50))
    age = db.Column(db.Integer)
    gender = db.Column(db.String(20))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    visits = db.relationship('Visit', backref='patient', cascade='all, delete-orphan', lazy=True)

class Visit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    visit_date = db.Column(db.Date, nullable=False, default=date.today)
    treatment_type = db.Column(db.String(150), nullable=False)
    dentist_name = db.Column(db.String(150), nullable=False)
    total_cost = db.Column(db.Numeric(12,2), nullable=False, default=0)
    paid = db.Column(db.Numeric(12,2), nullable=False, default=0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    @property
    def remaining(self):
        return Decimal(self.total_cost or 0) - Decimal(self.paid or 0)
    @property
    def payment_status(self):
        r = self.remaining
        if r <= 0: return 'مدفوع بالكامل'
        if self.paid and Decimal(self.paid) > 0: return 'مدفوع جزئيًا'
        return 'غير مدفوع'


def logged_in(): return 'user_id' in session

def login_required(view):
    from functools import wraps
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not logged_in(): return redirect(url_for('login', next=request.path))
        return view(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_globals():
    return {'today': date.today().isoformat(), 'logged_in': logged_in()}

@app.route('/health')
def health():
    return {'status': 'ok'}

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = User.query.filter_by(username=request.form.get('username','').strip()).first()
        if u and check_password_hash(u.password_hash, request.form.get('password','')):
            session['user_id'] = u.id
            session['username'] = u.username
            return redirect(request.args.get('next') or url_for('dashboard'))
        flash('اسم المستخدم أو كلمة المرور غير صحيحة.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    patients = Patient.query.count()
    today_visits = Visit.query.filter_by(visit_date=date.today()).count()
    visits = Visit.query.order_by(Visit.visit_date.desc(), Visit.id.desc()).limit(10).all()
    all_visits = Visit.query.all()
    outstanding = sum((v.remaining for v in all_visits), Decimal('0'))
    total_billed = sum((Decimal(v.total_cost or 0) for v in all_visits), Decimal('0'))
    total_paid = sum((Decimal(v.paid or 0) for v in all_visits), Decimal('0'))
    return render_template('dashboard.html', patients=patients, today_visits=today_visits, outstanding=outstanding, total_billed=total_billed, total_paid=total_paid, visits=visits)

@app.route('/patients')
@login_required
def patients():
    q = request.args.get('q','').strip()
    query = Patient.query
    if q:
        like = f'%{q}%'
        query = query.filter(db.or_(Patient.name.ilike(like), Patient.phone.ilike(like), Patient.patient_no.ilike(like)))
    return render_template('patients.html', patients=query.order_by(Patient.name).all(), q=q)

@app.route('/patients/new', methods=['GET','POST'])
@login_required
def new_patient():
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        if not name: flash('اسم المريض مطلوب.', 'danger'); return render_template('patient_form.html', patient=None)
        patient_no = request.form.get('patient_no','').strip() or f'P-{int(datetime.utcnow().timestamp())}'
        if Patient.query.filter_by(patient_no=patient_no).first():
            flash('رقم المريض مستخدم مسبقًا.', 'danger'); return render_template('patient_form.html', patient=None)
        p = Patient(patient_no=patient_no, name=name, phone=request.form.get('phone'), age=int(request.form['age']) if request.form.get('age') else None, gender=request.form.get('gender'), notes=request.form.get('notes'))
        db.session.add(p); db.session.commit(); flash('تم تسجيل المريض بنجاح.', 'success'); return redirect(url_for('patient_detail', pid=p.id))
    return render_template('patient_form.html', patient=None)

@app.route('/patients/<int:pid>')
@login_required
def patient_detail(pid):
    p = db.get_or_404(Patient, pid)
    return render_template('patient_detail.html', patient=p, dentists=Dentist.query.filter_by(active=True).order_by(Dentist.name).all(), treatments=TreatmentType.query.filter_by(active=True).order_by(TreatmentType.name).all())

@app.route('/patients/<int:pid>/edit', methods=['GET','POST'])
@login_required
def edit_patient(pid):
    p = db.get_or_404(Patient, pid)
    if request.method == 'POST':
        p.patient_no=request.form.get('patient_no','').strip() or p.patient_no; p.name=request.form.get('name','').strip(); p.phone=request.form.get('phone'); p.age=int(request.form['age']) if request.form.get('age') else None; p.gender=request.form.get('gender'); p.notes=request.form.get('notes'); db.session.commit(); flash('تم تحديث بيانات المريض.', 'success'); return redirect(url_for('patient_detail', pid=p.id))
    return render_template('patient_form.html', patient=p)

@app.route('/patients/<int:pid>/delete', methods=['POST'])
@login_required
def delete_patient(pid):
    p=db.get_or_404(Patient,pid); db.session.delete(p); db.session.commit(); flash('تم حذف المريض وسجل مراجعاته.', 'success'); return redirect(url_for('patients'))

@app.route('/visits/new/<int:pid>', methods=['POST'])
@login_required
def new_visit(pid):
    db.get_or_404(Patient,pid)
    try:
        total=Decimal(request.form.get('total_cost','0')); paid=Decimal(request.form.get('paid','0'))
        if total < 0 or paid < 0 or paid > total: raise ValueError()
        vd=datetime.strptime(request.form.get('visit_date'), '%Y-%m-%d').date()
        v=Visit(patient_id=pid, visit_date=vd, treatment_type=request.form.get('treatment_type','').strip(), dentist_name=request.form.get('dentist_name','').strip(), total_cost=total, paid=paid, notes=request.form.get('notes'))
        if not v.treatment_type or not v.dentist_name: raise ValueError()
        db.session.add(v); db.session.commit(); flash('تمت إضافة المراجعة والعلاج.', 'success')
    except Exception:
        flash('تحقق من التاريخ والعلاج والطبيب والمبالغ؛ المدفوع لا يمكن أن يتجاوز الإجمالي.', 'danger')
    return redirect(url_for('patient_detail', pid=pid))

@app.route('/visits/<int:vid>/delete', methods=['POST'])
@login_required
def delete_visit(vid):
    v=db.get_or_404(Visit,vid); pid=v.patient_id; db.session.delete(v); db.session.commit(); flash('تم حذف المراجعة.', 'success'); return redirect(url_for('patient_detail', pid=pid))

@app.route('/reports')
@login_required
def reports():
    start=request.args.get('start',''); end=request.args.get('end',''); dentist=request.args.get('dentist',''); treatment=request.args.get('treatment',''); status=request.args.get('status','')
    q=Visit.query
    if start:
        try:q=q.filter(Visit.visit_date>=datetime.strptime(start,'%Y-%m-%d').date())
        except:pass
    if end:
        try:q=q.filter(Visit.visit_date<=datetime.strptime(end,'%Y-%m-%d').date())
        except:pass
    if dentist:q=q.filter_by(dentist_name=dentist)
    if treatment:q=q.filter_by(treatment_type=treatment)
    visits=q.order_by(Visit.visit_date.desc()).all()
    if status=='paid': visits=[v for v in visits if v.remaining<=0]
    elif status=='partial': visits=[v for v in visits if v.remaining>0 and Decimal(v.paid or 0)>0]
    elif status=='unpaid': visits=[v for v in visits if Decimal(v.paid or 0)==0]
    total=sum((Decimal(v.total_cost or 0) for v in visits),Decimal('0')); paid=sum((Decimal(v.paid or 0) for v in visits),Decimal('0'))
    return render_template('reports.html', visits=visits, total=total, paid=paid, remaining=total-paid, dentists=Dentist.query.order_by(Dentist.name).all(), treatments=TreatmentType.query.order_by(TreatmentType.name).all(), filters=request.args)

@app.route('/settings', methods=['GET','POST'])
@login_required
def settings():
    if request.method=='POST':
        kind=request.form.get('kind'); name=request.form.get('name','').strip()
        if name:
            if kind=='dentist': db.session.add(Dentist(name=name))
            elif kind=='treatment': db.session.add(TreatmentType(name=name))
            db.session.commit(); flash('تمت الإضافة.', 'success')
        return redirect(url_for('settings'))
    return render_template('settings.html', dentists=Dentist.query.order_by(Dentist.name).all(), treatments=TreatmentType.query.order_by(TreatmentType.name).all())

@app.route('/settings/delete/<kind>/<int:item_id>', methods=['POST'])
@login_required
def settings_delete(kind,item_id):
    model = Dentist if kind=='dentist' else TreatmentType
    item=db.get_or_404(model,item_id); item.active=False; db.session.commit(); flash('تم تعطيل العنصر من القوائم.', 'success'); return redirect(url_for('settings'))

@app.route('/api/patients/<int:pid>')
@login_required
def api_patient(pid):
    p=db.get_or_404(Patient,pid)
    return jsonify({'id':p.id,'patient_no':p.patient_no,'name':p.name,'phone':p.phone,'visits':[{'date':v.visit_date.isoformat(),'treatment':v.treatment_type,'dentist':v.dentist_name,'total':float(v.total_cost),'paid':float(v.paid),'remaining':float(v.remaining),'status':v.payment_status} for v in p.visits]})

@app.cli.command('init-db')
def init_db():
    db.create_all()
    if not User.query.filter_by(username='admin').first(): db.session.add(User(username='admin',password_hash=generate_password_hash(os.environ.get('ADMIN_PASSWORD','admin123'))))
    if Dentist.query.count()==0: db.session.add_all([Dentist(name='طبيب العيادة')])
    if TreatmentType.query.count()==0: db.session.add_all([TreatmentType(name='فحص'),TreatmentType(name='حشوة'),TreatmentType(name='تنظيف'),TreatmentType(name='علاج عصب'),TreatmentType(name='تركيب تاج'),TreatmentType(name='قلع')])
    db.session.commit()
    print('Database initialized. Default username: admin. Set ADMIN_PASSWORD in production.')

with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        db.session.add(User(username='admin', password_hash=generate_password_hash(os.environ.get('ADMIN_PASSWORD','admin123'))))
    if Dentist.query.count()==0: db.session.add(Dentist(name='طبيب العيادة'))
    if TreatmentType.query.count()==0: db.session.add_all([TreatmentType(name='فحص'),TreatmentType(name='حشوة'),TreatmentType(name='تنظيف'),TreatmentType(name='علاج عصب'),TreatmentType(name='تركيب تاج'),TreatmentType(name='قلع')])
    db.session.commit()

if __name__=='__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT',5000)), debug=False)
